<?php

use RobThree\Auth\TwoFactorAuthException;

class RNGException extends TwoFactorAuthException {}